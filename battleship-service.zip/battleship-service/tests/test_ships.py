from ships import FLEET, check_fleet, from_coordinate, generate_fleet, to_coordinate

GOOD_FLEET = [
    {"coordinates": ["A1", "A2", "A3", "A4"]},
    {"coordinates": ["C1", "C2", "C3"]},
    {"coordinates": ["E1", "F1", "G1"]},
    {"coordinates": ["A6", "A7"]},
    {"coordinates": ["C6", "C7"]},
    {"coordinates": ["E6", "E7"]},
    {"coordinates": ["J1"]},
    {"coordinates": ["J3"]},
    {"coordinates": ["J5"]},
    {"coordinates": ["J7"]},
]


def change_ship(index, coordinates):
    fleet = [{"coordinates": list(ship["coordinates"])} for ship in GOOD_FLEET]
    fleet[index] = {"coordinates": coordinates}
    return fleet


def test_to_coordinate():
    assert to_coordinate(0, 0) == "A1"
    assert to_coordinate(3, 6) == "D7"
    assert to_coordinate(9, 9) == "J10"


def test_from_coordinate():
    assert from_coordinate("A1") == (0, 0)
    assert from_coordinate("D7") == (3, 6)
    assert from_coordinate("J10") == (9, 9)


def test_from_coordinate_with_wrong_values():
    assert from_coordinate("K1") is None
    assert from_coordinate("A0") is None
    assert from_coordinate("A11") is None
    assert from_coordinate("1A") is None
    assert from_coordinate("A") is None
    assert from_coordinate("") is None


def test_good_fleet():
    assert check_fleet(GOOD_FLEET) is True


def test_fleet_without_ship():
    assert check_fleet(GOOD_FLEET[:-1]) is False


def test_ship_with_five_decks():
    assert check_fleet(change_ship(0, ["A1", "A2", "A3", "A4", "A5"])) is False


def test_ship_is_not_line():
    assert check_fleet(change_ship(1, ["C1", "C2", "D2"])) is False


def test_ship_with_gap():
    assert check_fleet(change_ship(1, ["C1", "C2", "C4"])) is False


def test_ship_outside_field():
    assert check_fleet(change_ship(6, ["K1"])) is False
    assert check_fleet(change_ship(6, ["A11"])) is False


def test_ships_on_one_cell():
    assert check_fleet(change_ship(3, ["C1", "C2"])) is False


def test_ships_touch_by_side():
    assert check_fleet(change_ship(3, ["B1", "B2"])) is False


def test_ships_touch_by_corner():
    assert check_fleet(change_ship(6, ["B5"])) is False


def test_generated_fleet_is_correct():
    for attempt in range(200):
        ships = generate_fleet()
        assert check_fleet(ships) is True


def test_generated_fleet_has_ten_ships():
    ships = generate_fleet()
    sizes = [len(ship["coordinates"]) for ship in ships]
    assert sorted(sizes, reverse=True) == FLEET


def test_generated_fleets_are_different():
    first = generate_fleet()
    fleets = [generate_fleet() for attempt in range(20)]
    assert first not in fleets
