import uuid

from models import Game
from ships import check_fleet


def test_health(client):
    response = client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_new_game(client):
    response = client.post("/game")

    assert response.status_code == 201

    data = response.json()
    assert "session_id" in data
    assert len(data["ships"]) == 10


def test_new_game_returns_correct_fleet(client):
    data = client.post("/game").json()

    assert check_fleet(data["ships"]) is True


def test_new_game_is_saved_in_database(client, db):
    data = client.post("/game").json()

    game = db.get(Game, uuid.UUID(data["session_id"]))

    assert game is not None
    assert game.status == "active"
    assert game.ships == data["ships"]


def test_two_games_are_different(client, db):
    first = client.post("/game").json()
    second = client.post("/game").json()

    assert first["session_id"] != second["session_id"]

    game = db.get(Game, uuid.UUID(second["session_id"]))
    assert game.ships == second["ships"]
