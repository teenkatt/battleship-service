"""create games table

Revision ID: b7c41d0a9e32
Revises:
Create Date: 2026-09-02 21:14:03.118472

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "b7c41d0a9e32"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "games",
        sa.Column("session_id", sa.Uuid(as_uuid=True), nullable=False),
        sa.Column("ships", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("session_id"),
    )


def downgrade() -> None:
    op.drop_table("games")
